files = dir( 'transform_*.txt' );
lgd = cell( length(files), 1 );
figure(1)
a11 = gca; hold on
a11.Box = 'on';
grid on
figure(2)
a21 = gca; hold on
a21.Box = 'on';
grid on

lgd_set = {'Proposed','Ouyang et al.[11]','Su et al.[6]'};
colors = [0 0 1; 1 0 0; 0 1 0; 0 1 0; 1 1 0];

for i = 1 : length(files)
    %a = importdata( [p_perf files(i).name] );
    a = importdata( [files(i).name] );
%     lgd{i} = files(i).name(11:end-4);
    lgd{i} = lgd_set{i};

    figure(1)
    hold on
    [n,x] = ecdf( a(:,1) );
    n = n*100;
    plot( a11, x, n, 'linewidth', 1.5,  'color', colors(i,:));%, styles{i} );
    xlabel( a11,'Deviation in location (pixels)' );
    ylabel( a11, 'Empirical cdf(%)' );

    figure(2)
    hold on
    [n, x] = ecdf( abs(a(:,2)) );
    n = n*100;
    plot( a21, x, n, 'linewidth', 1.5, 'color', colors(i,:) );%, styles{i} );
    xlabel( a21, 'Deviation in direction (degrees)' );
    ylabel( a21, 'Empirical cdf(%)' );
end

for i = 1: 2
    figure(i)
    legend( lgd,'Interpreter','none', 'Location', 'SouthEast' );
end
xlim( a11, [0 100]);
xlim( a21, [0 20]);
ylim( a11, [80 100] );
ylim( a21, [80 100] );
