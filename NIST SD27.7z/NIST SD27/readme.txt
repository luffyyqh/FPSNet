run pose_eva.m to evaluate pose estimation by minutiae pairs.
