
num = 258;
id_range = 1:258;


diff_pos = zeros(258,2);
diff_ang = zeros(258,2);

offset = 0;

for i = id_range
    ftitle = num2str(i);

    Minu_latent = load(['minutiae_pair\minutiae\m' ftitle '_1.txt']);
    Minu_latent = Minu_latent(:,1:3);
 
    pose_latent = load(['search\pose_yang\pose_' ftitle '.txt']);

    Minu1 = Minu_latent - repmat(pose_latent,size(Minu_latent,1),1);
    Minu1(:,3) = NormalizeMinuDir(Minu1(:,3));
    
    

    Minu_file = load(['minutiae_pair\minutiae\m' ftitle '_2.txt']);
    Minu_file = Minu_file(:,1:3);
 
    pose_file = load(['file\pose_yang\pose_' ftitle '.txt']);
 
    Minu2 = Minu_file - repmat(pose_file,size(Minu_file,1),1);
    Minu2(:,3) = NormalizeMinuDir(Minu2(:,3));
    
    Pair = load(['minutiae_pair\minutiae\p' ftitle '_' ftitle '.txt']);
    sum_pos = 0;
    sum_ang = 0;
    for j = 1:size(Pair,1);
        idx1 = Pair(j,1)+1;
        idx2 = Pair(j,2)+1;
        temp_pos = pdist2(Minu1(idx1,1:2),Minu2(idx2,1:2));
        sum_pos = sum_pos + temp_pos;
        temp_ang = abs(NormalizeMinuDir(Minu1(idx1,3)-Minu2(idx2,3)));

        sum_ang = sum_ang+temp_ang;
    end
    diff_pos(i,1) = sum_pos/size(Pair,1);
    diff_ang(i,1) = sum_ang/size(Pair,1);
end

for i = id_range
    ftitle = num2str(i);

    Minu_latent = load(['minutiae_pair\minutiae\m' ftitle '_1.txt']);
    Minu_latent = Minu_latent(:,1:3);
  
    pose_latent = load(['search\pose_proposed\' ftitle '.txt']);
   
    Minu1 = Minu_latent - repmat(pose_latent,size(Minu_latent,1),1);
    Minu1(:,3) = NormalizeMinuDir(Minu1(:,3));
    

    Minu_file = load(['minutiae_pair\minutiae\m' ftitle '_2.txt']);
    Minu_file = Minu_file(:,1:3);
 
    pose_file = load(['file\pose_proposed\' ftitle '.txt']);
  
    Minu2 = Minu_file - repmat(pose_file,size(Minu_file,1),1);
    Minu2(:,3) = NormalizeMinuDir(Minu2(:,3));
    
    Pair = load(['minutiae_pair\minutiae\p' ftitle '_' ftitle '.txt']);
    sum_pos = 0;
    sum_ang = 0;
    for j = 1:size(Pair,1);
        idx1 = Pair(j,1)+1;
        idx2 = Pair(j,2)+1;
        temp_pos = pdist2(Minu1(idx1,1:2),Minu2(idx2,1:2));
        sum_pos = sum_pos + temp_pos;
        temp_ang = abs(NormalizeMinuDir(Minu1(idx1,3)-Minu2(idx2,3)));
  
        sum_ang = sum_ang+temp_ang;
    end
    diff_pos(i,2) = sum_pos/size(Pair,1);
    diff_pos(i,2) = diff_pos(i,2);
    diff_ang(i,2) = sum_ang/size(Pair,1);
end


[n1,x1] = ecdf(diff_pos(:,1));
[n2,x2] = ecdf(diff_ang(:,1));
[n3,x3] = ecdf(diff_pos(:,2));
[n4,x4] = ecdf(diff_ang(:,2));

n3 = n3*100;
figure(1);
plot(x3,n3,'b','linewidth',1.5);
hold on
n1 = n1*100;

plot(x1,n1,'m','linewidth',1.5);

set(gca,'XLim',[0 100]);
set(gca,'YLim',[0 100]);
legend('Proposed','Yang et al [3]','Location','SouthEast');
xlabel('Deviation in location (pixels)');
ylabel('Expirical cdf(%)');
grid on;

n4 = n4*100;
figure(2);
plot(x4,n4,'b','linewidth',1.5);
hold on;
n2 = n2*100;

plot(x2,n2,'m','linewidth',1.5);


set(gca,'XLim',[0 35]);
set(gca,'YLim',[0 100]);
legend('Proposed','Yang et al [3]','Location','SouthEast');

xlabel('Deviation in direction (degrees)');
ylabel('Expirical cdf(%)');
grid on;

